Place your hero slider images here with these filenames so they load automatically:

- hero-slide-1.jpg
- hero-slide-2.jpg
- hero-slide-3.jpg
- hero-slide-4.jpg

They are referenced in `copy_of_giordora_luxury_boutique.jsx` as `/images/hero-slide-#.jpg`. Replace the files with your assets (JPG/PNG/WebP all work) and keep the names the same.***
